# 文件结构

## renju.py

五子棋pygame类模块，用于后端

## main.py

估值函数，搜索策略，AlphaBeta剪枝，以及调用renju模块

## *.png, simhei.ttf

资源文件，用于展示五子棋界面